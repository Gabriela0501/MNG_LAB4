package edu.wat.tim.lab1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
